<footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Movie Recommandation System 2023</span></div>
                </div>
            </footer>