<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<title>Dashboard </title>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="./assets/fonts/font.css">
<link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
<!-- <script src="assets\js\code.jquery.com_jquery-3.5.1.slim.min.js"></script> -->
<script src="assets/js/code.jquery.com_jquery-3.6.0.min.js"></script>

<!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css"> -->
<!-- <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script> -->