<?php 
session_start();
if(isset($_SESSION['admin_logged_in'])){
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <!-- headLinks -->
    <?php include 'headLinks.php'; ?>
    <!-- headLinks end -->
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- sidebar end-->
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <!-- navbar -->
                <?php include 'navbar.php'; ?>
                <!-- navbar end -->
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">LANGUAGE</h3>
                    </div>
                    <!-- Add Button to open the Add language Modal -->
                    <div class="container mt-4 " >
                        <button type="button" class="btn btn-primary " data-bs-toggle="modal"
                            data-bs-target="#addlanguageModal">
                            Add language
                        </button>
                    </div>

                    <!-- Add language Modal -->
                    <div class="modal fade" id="addlanguageModal" tabindex="-1" role="dialog"
                        aria-labelledby="addlanguageModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addlanguageModalLabel">Add language Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Add language Information -->
                                    <form id="addlanguageForm" method="post">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" id="name" name="name" required>
                                        </div>
                                        <button type="submit" name="add" class="btn btn-primary mt-2">Add language</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit language Modal -->
                    <div class="modal fade" id="editlanguageModal" tabindex="-1" role="dialog"
                        aria-labelledby="editlanguageModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editlanguageModalLabel">Edit language Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Edit language Information -->
                                    <form id="editlanguageForm">
                                        <input type="hidden" id="editlanguageId" name="id">
                                        <div class="form-group">
                                            <label for="editName">Name</label>
                                            <input type="text" class="form-control" id="editName" name="name" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delete Confirmation Modal -->
                    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog"
                        aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to delete this record?</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-danger" id="deletelanguageBtn">Delete</button>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Table to display language records -->
                    <div class="container mt-4">
                        <table class="table" id="language-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
            <!-- footer -->
            <?php include 'footer.php'; ?>
            <!-- footer end -->
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
     <!-- js -->
     <?php include 'jsScripts.php'; ?>
        <!-- js end -->
        <script>
    $.ajax({
        method:"GET",
        url:"./server/languageCrud.php",
        dataType:"json",
        success:function(response){
            $('#language-table tbody').empty();
            response.forEach(function(lang){
                $('#language-table tbody').append(
                    `<tr>
                                    <td>${lang.id}</td>
                                    <td>${lang.name}</td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary editlanguageBtn" data-id="${lang.id}"
                                            data-name="${lang.name}">Edit</button>
                                        <button type="button" class="btn btn-sm btn-danger deletelanguageBtn"
                                            data-id="${lang.id}">Delete</button>
                                    </td>
                                </tr>`
                );
            });
        }
    });
</script>

    <script>
        $(document).ready(function () {


            // Add language Form Submission
            $('#addlanguageForm').submit(function (event) {
                event.preventDefault();
                const name = $('#name').val();
                console.log('Add language Information:', name);
                $.ajax({
                    method:"POST",
                    url:"./server/languageCrud.php",
                    data:{
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#addlanguageModal').modal('hide');
                        location.reload();
                    }
                });
                
            });


            // Edit language Form Submission
            $('#editlanguageForm').submit(function (event) {
                event.preventDefault();
                const id = $('#editlanguageId').val();
                const name = $('#editName').val();
                console.log('Edit language Information:', { id, name });
                $.ajax({
                    method:"POST",
                    url:"./server/languageCrud.php",
                    data:{
                        id:id,
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#editlanguageModal').modal('hide');
                        location.reload();
                    }
                });
                
            });

            // Open Edit language Modal and pre-fill data
            $(document).on('click','.editlanguageBtn',function(){
                const id = $(this).data('id');
                const name = $(this).data('name');
                $('#editlanguageId').val(id);
                $('#editName').val(name);
                $('#editlanguageModal').modal('show');
            });

            // Open Delete Confirmation Modal
            $(document).on('click','.deletelanguageBtn',function(){
                const id = $(this).data('id');
                $('#deletelanguageBtn').data('id', id);
                $('#deleteConfirmationModal').modal('show');
            });

            // Delete language Data
            $('#deletelanguageBtn').click(function () {
                const id = $(this).data('id');
                console.log('Delete language Information:', id);
                $.ajax({
                    method:"POST",
                    url:"./server/languageCrud.php",
                    data:{
                        id:id
                    },
                    dataType:"json",
                    success:function(response){
                        $('#deleteConfirmationModal').modal('hide');
                        location.reload();
                    }
                });
            });

        });
    </script>
</body>

</html>
<?php
}else{
    header("Location:LoginPage.php");
}?>