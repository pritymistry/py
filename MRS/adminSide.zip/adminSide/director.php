<?php 
session_start();
if(isset($_SESSION['admin_logged_in'])){
?>

<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <!-- headLinks -->
    <?php include 'headLinks.php'; ?>
    <!-- headLinks end -->
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- sidebar -->
        <?php include 'sidebar.php'; ?>
            <!-- sidebar end-->
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <!-- navbar -->
                <?php include 'navbar.php'; ?>
                <!-- navbar end -->
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">DIRECTOR</h3>
                    </div>
                    <!-- Add Button to open the Add director Modal -->
                    <div class="container mt-4 " >
                        <button type="button" class="btn btn-primary " data-bs-toggle="modal"
                            data-bs-target="#adddirectorModal">
                            Add director
                        </button>
                    </div>

                    <!-- Add director Modal -->
                    <div class="modal fade" id="adddirectorModal" tabindex="-1" role="dialog"
                        aria-labelledby="adddirectorModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="adddirectorModalLabel">Add director Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Add director Information -->
                                    <form id="adddirectorForm" method="post">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" id="name" name="name" required>
                                        </div>
                                        <button type="submit" name="add" class="btn btn-primary mt-2">Add director</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit director Modal -->
                    <div class="modal fade" id="editdirectorModal" tabindex="-1" role="dialog"
                        aria-labelledby="editdirectorModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editdirectorModalLabel">Edit director Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Edit director Information -->
                                    <form id="editdirectorForm">
                                        <input type="hidden" id="editdirectorId" name="id">
                                        <div class="form-group">
                                            <label for="editName">Name</label>
                                            <input type="text" class="form-control" id="editName" name="name" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delete Confirmation Modal -->
                    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog"
                        aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to delete this record?</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-danger" id="deletedirectorBtn">Delete</button>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Table to display director records -->
                    <div class="container mt-4">
                        <table class="table" id="director-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
            <!-- footer -->
            <?php include 'footer.php'; ?>
            <!-- footer end -->
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
        <!-- js -->
        <?php include 'jsScripts.php'; ?>
        <!-- js end -->
<script>
    $.ajax({
        method:"GET",
        url:"./server/directorCrud.php",
        dataType:"json",
        success:function(response){
            $('#director-table tbody').empty();
            response.forEach(function(director){
                $('#director-table tbody').append(
                    `<tr>
                        <td>${director.id}</td>
                        <td>${director.name}</td>
                        <td>
                            <button type="button" class="btn btn-sm btn-primary editdirectorBtn" data-id="${director.id}"
                                data-name="${director.name}">Edit</button>
                            <button type="button" class="btn btn-sm btn-danger deletedirectorBtn"
                                data-id="${director.id}">Delete</button>
                        </td>
                    </tr>`
                );
            });
        }
    });
</script>

    <script>
        $(document).ready(function () {


            // Add director Form Submission
            $('#adddirectorForm').submit(function (event) {
                event.preventDefault();
                const name = $('#name').val();
                
                console.log('Add director Information:', name);
                $.ajax({
                    method:"POST",
                    url:"./server/directorCrud.php",
                    data:{
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#adddirectorModal').modal('hide');
                        location.reload();
                    }
                });
                
            });


            // Edit director Form Submission
            $('#editdirectorForm').submit(function (event) {
                event.preventDefault();
                const id = $('#editdirectorId').val();
                const name = $('#editName').val();
                console.log('Edit director Information:', { id, name });
                $.ajax({
                    method:"POST",
                    url:"./server/directorCrud.php",
                    data:{
                        id:id,
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#editdirectorModal').modal('hide');
                        location.reload();
                    }
                });
            });

            // Open Edit director Modal and pre-fill data
            $(document).on('click','.editdirectorBtn',function(){
                const id = $(this).data('id');
                const name = $(this).data('name');
                $('#editdirectorId').val(id);
                $('#editName').val(name);
                $('#editdirectorModal').modal('show');
            });

            // Open Delete Confirmation Modal
            $(document).on('click','.deletedirectorBtn',function(){
                const id = $(this).data('id');
                $('#deletedirectorBtn').data('id', id);
                $('#deleteConfirmationModal').modal('show');
            });

            // Delete director Data
            $('#deletedirectorBtn').click(function () {
                const id = $(this).data('id');
                console.log('Delete director Information:', id);
                $.ajax({
                    method:"POST",
                    url:"./server/directorCrud.php",
                    data:{
                        id:id
                    },
                    dataType:"json",
                    success:function(response){
                        $('#deleteConfirmationModal').modal('hide');
                        location.reload();
                    }
                });
            });

        });
    </script>
</body>

</html>
<?php
}else{
    header("Location:LoginPage.php");
}?>