<?php
session_start();
if (isset($_SESSION['admin_logged_in'])) {

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mrc";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $allCastSql = "select * from casts";
    $allCastFetch = mysqli_query($conn, $allCastSql);
    $allCast = $allCastFetch->fetch_all(MYSQLI_ASSOC);

    $allCategorySql = "select * from categories";
    $allCategoryFetch = mysqli_query($conn, $allCategorySql);
    $allCategory = $allCategoryFetch->fetch_all(MYSQLI_ASSOC);

    $allDirectorSql = "select * from directors";
    $allDirectorFetch = mysqli_query($conn, $allDirectorSql);
    $allDirector = $allDirectorFetch->fetch_all(MYSQLI_ASSOC);

    $allGenresSql = "select * from genres";
    $allGenresFetch = mysqli_query($conn, $allGenresSql);
    $allGenres = $allGenresFetch->fetch_all(MYSQLI_ASSOC);

    $allLanguagesSql = "select * from languages";
    $allLanguagesFetch = mysqli_query($conn, $allLanguagesSql);
    $allLanguages = $allLanguagesFetch->fetch_all(MYSQLI_ASSOC);

    $allTagsSql = "select * from tags";
    $allTagsFetch = mysqli_query($conn, $allTagsSql);
    $allTags = $allTagsFetch->fetch_all(MYSQLI_ASSOC);

    $allWritersSql = "select * from writers";
    $allWritersFetch = mysqli_query($conn, $allWritersSql);
    $allWriters = $allWritersFetch->fetch_all(MYSQLI_ASSOC);
    // echo "<pre>";
    // print_r($allWriters);
    // echo "<pre>";
    // print_r($allTags);

    // echo "<pre>";
    // print_r($allCast);
    // echo "<pre>";
    // print_r($allCategory);
    // echo "<pre>";
    // print_r($allDirector);
    // echo "<pre>";
    // print_r($allGenres);
    // echo "<pre>";
    // print_r($allLanguages);


?>

    <!DOCTYPE html>
    <html data-bs-theme="light" lang="en">

    <head>
        <!-- headLinks -->
        <?php include 'headLinks.php'; ?>
        <!-- headLinks end -->
    </head>

    <body id="page-top">
        <div id="wrapper">
            <!-- sidebar -->
            <?php include 'sidebar.php'; ?>
            <!-- sidebar end-->
            <div class="d-flex flex-column" id="content-wrapper">
                <div id="content">
                    <!-- navbar -->
                    <?php include 'navbar.php'; ?>
                    <!-- navbar end -->
                    <div class="container-fluid">
                        <div class="d-sm-flex justify-content-between align-items-center mb-4">
                            <h3 class="text-dark mb-0">MOVIE</h3>
                        </div>
                        <!-- Add Button to open the Add movie Modal -->
                        <div class="container mt-4 ">
                            <button type="button" class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#addmovieModal">
                                Add movie
                            </button>
                        </div>

                        <!-- Add movie Modal -->
                        <div class="modal fade" id="addmovieModal" tabindex="-1" role="dialog" aria-labelledby="addmovieModalLabel" aria-hidden="true">
                            <!-- Modal content... -->
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addmovieModalLabel">Add movie Information</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Form to Add movie Information -->
                                        <form id="addmovieForm" method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label for="name">Movie Name</label>
                                                <input type="text" class="form-control" id="name" name="name" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="description" class="form-label">Description</label>
                                                <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                                            </div>
                                            <div class="mb-3">
                                                <label for="date" class="form-label">Release Date</label>
                                                <input type="date" class="form-control" id="date" name="date" required>
                                            </div>
                                            <div>
                                                <label for="img" class="form-label">Image</label>
                                                <input class="form-control form-control-lg" id="img" type="file" accept="image/*">
                                                <img src="#" class="img-thumbnail" alt="...">
                                            </div>

                                            <button type="submit" name="add" class="btn btn-primary mt-2">Add movie</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Edit movie Modal -->
                        <div class="modal fade" id="editmovieModal" tabindex="-1" role="dialog" aria-labelledby="editmovieModalLabel" aria-hidden="true">
                            <!-- Modal content... -->
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editmovieModalLabel">Edit movie Information</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Form to Edit movie Information -->
                                        <!-- Edit movie Form -->
                                        <form id="editmovieForm" method="post" enctype="multipart/form-data">
                                            <input type="hidden" id="editmovieId" name="id">
                                            <div class="form-group">
                                                <label for="editName">Movie Title</label>
                                                <input type="text" class="form-control" id="editName" name="name" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="editDescription">Description</label>
                                                <textarea class="form-control" name="description" id="editDescription" rows="3"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="editDate">Release Date</label>
                                                <input type="date" class="form-control" id="editDate" name="date" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="editImg">Image</label>
                                                <input class="form-control form-control-lg" id="editImg" type="file" accept="image/*">
                                                <img src="" id="showImg" class="img-thumbnail" alt="Movie IMG">
                                            </div>
                                            <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Delete Confirmation Modal -->
                        <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
                            <!-- Modal content... -->
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Are you sure you want to delete this record?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="button" class="btn btn-danger" id="deletemovieBtn">Delete</button>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- details for movie  -->
                        <div class="modal fade" id="detailsMovieModel" tabindex="-1" role="dialog" aria-labelledby="detailsMovieModelLabel" aria-hidden="true">
                            <!-- Modal content... -->
                            <div class="modal-dialog modal-xl" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="detailsMovieModelLabel">Movie Details</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post">
                                            <table class="table table-bordered">
                                                <tr class="cast-section">
                                                    <th>Cast</th>
                                                    <td>
                                                        <?php
                                                        foreach ($allCast as $r) {
                                                        ?>
                                                            <span class="checkbox-container mx-1">
                                                                <span class="checkbox-title px-1"><?php echo $r["name"]; ?></span>
                                                                <input type="checkbox" name="cast[]" value="<?php echo $r["id"]; ?>" id="">
                                                            </span>
                                                        <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr class="category-section">
                                                    <th>Category</th>
                                                    <td>
                                                        <?php
                                                        foreach ($allCategory as $r) {
                                                        ?>
                                                            <span class="checkbox-container mx-1">
                                                                <span class="checkbox-title px-1"><?php echo $r["name"]; ?></span>
                                                                <input type="checkbox" name="category[]" value="<?php echo $r["id"]; ?>" id="">
                                                            </span>
                                                        <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr class="director-section">
                                                    <th>Director</th>
                                                    <td>
                                                        <?php
                                                        foreach ($allDirector as $r) {
                                                        ?>
                                                            <span class="checkbox-container mx-1">
                                                                <span class="checkbox-title px-1"><?php echo $r["name"]; ?></span><input type="checkbox" name="director[]" value="<?php echo $r["id"]; ?>" id="">
                                                            </span>
                                                        <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr class="genres-section">
                                                    <th>Genres</th>
                                                    <td>
                                                        <?php
                                                        foreach ($allGenres as $r) {
                                                        ?>
                                                            <span class="checkbox-container mx-1">
                                                                <span class="checkbox-title px-1"><?php echo $r["name"]; ?></span><input type="checkbox" name="genres[]" value="<?php echo $r["id"]; ?>" id="">
                                                            </span>
                                                        <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr class="languages-section">
                                                    <th>Languages</th>
                                                    <td>
                                                        <?php
                                                        foreach ($allLanguages as $r) {
                                                        ?>
                                                            <span class="checkbox-container mx-1">
                                                                <span class="checkbox-title px-1"><?php echo $r["name"]; ?></span><input type="checkbox" name="languages[]" value="<?php echo $r["id"]; ?>" id="">
                                                            </span>
                                                        <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr class="tags-section">
                                                    <th>Tags</th>
                                                    <td>
                                                        <?php
                                                        foreach ($allTags as $r) {
                                                        ?>
                                                            <span class="checkbox-container mx-1">
                                                                <span class="checkbox-title px-1"><?php echo $r["name"]; ?></span><input type="checkbox" name="tags[]" value="<?php echo $r["id"]; ?>" id="">
                                                            </span>
                                                        <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr class="writers-section">
                                                    <th>Writers</th>
                                                    <td>
                                                        <?php
                                                        foreach ($allWriters as $r) {
                                                        ?>
                                                            <span class="checkbox-container mx-1">
                                                                <span class="checkbox-title px-1"><?php echo $r["name"]; ?></span><input type="checkbox" name="writers[]" value="<?php echo $r["id"]; ?>" id="">
                                                            </span>
                                                        <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>


                                            </table>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="button" class="btn btn-danger" id="detailsMovieBtn">Save</button>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <!-- Table to display movie records -->
                        <div class="container mt-4">
                            <div class="row" id="card-movie">

                            </div>
                            <!-- <table class="table" id="movies-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table> -->
                        </div>


                    </div>
                </div>
                <!-- footer -->
                <?php include 'footer.php'; ?>
                <!-- footer end -->
            </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
        </div>
        <!-- js -->
        <?php include 'jsScripts.php'; ?>
        <!-- js end -->
        <script>
            $.ajax({
                method: "GET",
                url: "./server/movieCrud.php",
                dataType: "json",
                success: function(response) {
                    $('#card-movie .card-m').empty();
                    response.forEach(function(movies) {

                        var movieCard =
                            `
        <div class="col-4 mb-3">
            <div class="card movie-card" data-movie-id="${movies.id}" style="width: 18rem;">
            <img src="./server/` + movies.image_url + `" class="card-img-top" alt="` + movies.title + `">
  <div class="card-body">
    <h5 class="card-title">` + movies.title + `</h5>
    <p class="card-text">` + movies.description + `</p>
    <button type="button" class="btn btn-sm btn-secondary detailsMovieBtn"
                                            data-id=${movies.id}>Details</button>
    <button type="button"  class="btn btn-sm btn-primary editMovieBtn" data-id=${movies.id}
                                        data-name="${movies.title}" data-description="${movies.description}" data-date="${movies.release_date}" data-img-url="${movies.image_url}">Edit</button>
    <button type="button" class="btn btn-sm btn-danger deletemovieBtn"
                                            data-id=${movies.id}>Delete</button>
    
  </div>
            </div>
        </div>
    `;
                        $('#card-movie').append(movieCard);
                        //     $('.movie-card').click(function () {
                        //     const movieId = $(this).data('movie-id');
                        //     // Set the movie ID in the modal
                        //     $('#editmovieId').val(movieId);
                        //     $('#deletemovieBtn').data('movie-id', movieId);
                        //     // Open the modal
                        //     $('#editmovieModal').modal('show');

                        // });

                    });



                    //             //
                    //             response.forEach(function(movies){
                    //                 $('#card-movie .card-m').append(
                    //                     `<div class="card" style="width: 18rem;">
                    //   <img src="./server/`+movies.image_url+`" class="card-img-top" alt="`+movies.title+`">
                    //   <div class="card-body">
                    //     <h5 class="card-title">`+movies.title+`</h5>
                    //     <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    //     <a href="#" class="btn btn-primary">Go somewhere</a>
                    //   </div>
                    // </div>`
                    //                 );
                    // console.log("movies detail : "+movies.image_url);
                    //             });//
                }
            });
            $(document).ready(function() {
                // Add movie Form Submission
                $('#addmovieForm').submit(function(event) {
                    event.preventDefault();
                    var file_data = $("#img").prop("files")[0];
                    const name = $('#name').val();
                    const description = $('#description').val();
                    const date = $('#date').val();
                    const crud_type = "add";
                    var formData = new FormData();
                    formData.append("name", name);
                    formData.append("description", $('#description').val());
                    formData.append("date", $('#date').val());
                    formData.append("crud_type", crud_type);
                    formData.append("file", file_data);
                    $.ajax({
                        type: "POST",
                        url: "./server/movieCrud.php",
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false,
                        dataType: "script",
                        success: function(response) {
                            $('#addmovieModal').modal('hide');
                            location.reload();
                            //console.log('Add movie Information:', filename);
                            //console.log('response:', response);
                        }
                    });


                    // const name = $('#name').val();
                    // var filename=$("#img").val();
                    // const description = $('#description').val();
                    // const date = $('#date').val();
                    // const filename = $("#img")[0].files[0];
                    //     var formData = new FormData();
                    //     formData.append("name", name);
                    //     formData.append("description", $('#description').val());
                    //     formData.append("date", $('#date').val());
                    //     formData.append("img", $("#img")[0].files[0]);
                    //    console.log("in jquery");                
                });
                // Open Details Confirmation Modal
                $(document).on('click', '.detailsMovieBtn', function() {
                    const id = $(this).data('id');
                    $('#detailsMovieBtn').data('id', id);
                    $('#detailsMovieModel').modal('show');

                });
                $('#detailsMovieBtn').click(function() {
                    //how to get value from checkbox cast[],category[],director[],genres[],languages[],tags[],writers[]
                    var cast = [];
                    var category = [];
                    var director = [];
                    var genres = [];
                    var languages = [];
                    var tags = [];
                    var writers = [];
                    var movie_id = $('#detailsMovieBtn').data('id');

                    $('input[name="cast[]"]:checked').each(function() {
                        cast.push(this.value);
                    });
                    $('input[name="category[]"]:checked').each(function() {
                        category.push(this.value);
                    });
                    $('input[name="director[]"]:checked').each(function() {
                        director.push(this.value);
                    });
                    $('input[name="genres[]"]:checked').each(function() {
                        genres.push(this.value);
                    });
                    $('input[name="languages[]"]:checked').each(function() {
                        languages.push(this.value);
                    });
                    $('input[name="tags[]"]:checked').each(function() {
                        tags.push(this.value);
                    });
                    $('input[name="writers[]"]:checked').each(function() {
                        writers.push(this.value);
                    });
                    console.log("movie id : ", movie_id);
                    console.log("cast : ", cast);
                    console.log("category : ", category);
                    console.log("director : ", director);
                    console.log("genres : ", genres);
                    console.log("languages : ", languages);
                    console.log("tags : ", tags);
                    console.log("writers : ", writers);
                    // End of how to get value from checkbox cast[],category[],director[],genres[],languages[],tags[],writers[]
                    $.ajax({
                        method: "POST",
                        url: "./server/movieDetails.php",
                        data: {
                            id: movie_id,
                            cast: cast,
                            category: category,
                            director: director,
                            genres: genres,
                            languages: languages,
                            tags: tags,
                            writers: writers
                        },
                        dataType: "json",
                        success: function(response) {
                            console.log(response);
                            $('#detailsMovieModel').modal('hide');
                            location.reload();
                        }
                    });
                    $('#detailsMovieModel').modal('hide');
                });

                // Edit movie Form Submission
                $('#editmovieForm').submit(function(event) {
                    event.preventDefault();
                    const id = $('#editmovieId').val();
                    const name = $('#editName').val();
                    const date = $('#editDate').val();
                    const crud_type = "edit";
                    const description = $('#editDescription').val();
                    var file_data = $("#editImg").prop("files")[0];
                    var formData = new FormData();
                    formData.append("id", id);
                    formData.append("name", name);
                    formData.append("description", description);
                    formData.append("date", date);
                    formData.append("crud_type", crud_type);
                    formData.append("file", file_data);
                    $.ajax({
                        type: "POST",
                        url: "./server/movieCrud.php",
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false,
                        dataType: "script",
                        success: function(response) {
                            $('#editmovieModal').modal('hide');
                            location.reload();
                            //console.log('Add movie Information:', filename);
                            //console.log('response:', response);
                        }
                    });



                    $('#editmovieModal').modal('hide');
                });

                // Open Edit movie Modal and pre-fill data
                $(document).on('click', '.editMovieBtn', function() {
                    const id = $(this).data('id');
                    const name = $(this).data('name');
                    const description = $(this).data('description');
                    const date = $(this).data('date');
                    const movieImgUrl = $(this).data('img-url');
                    $('#editmovieId').val(id);
                    $('#editName').val(name);
                    $('#editDescription').val(description);
                    $('#editDate').val(date);
                    console.log("img url : ", movieImgUrl);
                    $('#showImg').attr('src', './server/' + movieImgUrl);
                    $('#editImg').attr('src', './server/' + movieImgUrl);
                    $('#editmovieModal').modal('show');
                });

                // Open Delete Confirmation Modal
                $(document).on('click', '.deletemovieBtn', function() {
                    const id = $(this).data('id');
                    $('#deletemovieBtn').data('id', id);
                    $('#deleteConfirmationModal').modal('show');
                });

                // Delete movie Data
                $('#deletemovieBtn').click(function() {
                    const id = $(this).data('id');
                    const crud_type = "delete";
                    console.log('Delete movie Information:', id);

                    $.ajax({
                        method: "POST",
                        url: "./server/movieCrud.php",
                        data: {
                            id: id,
                            crud_type: crud_type
                        },
                        dataType: "json",
                        success: function(response) {
                            $('#deleteConfirmationModal').modal('hide');
                            location.reload();
                        }
                    });

                });

            });
        </script>
    </body>

    </html>
<?php
} else {
    header("Location:LoginPage.php");
} ?>