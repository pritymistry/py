<?php 
session_start();
if(isset($_SESSION['admin_logged_in'])){
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <!-- headLinks -->
    <?php include 'headLinks.php'; ?>
    <!-- headLinks end -->
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- sidebar end-->
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <!-- navbar -->
                <?php include 'navbar.php'; ?>
                <!-- navbar end -->
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">GENRES</h3>
                    </div>
                    <!-- Add Button to open the Add genres Modal -->
                    <div class="container mt-4 " >
                        <button type="button" class="btn btn-primary " data-bs-toggle="modal"
                            data-bs-target="#addgenresModal">
                            Add genres
                        </button>
                    </div>

                    <!-- Add genres Modal -->
                    <div class="modal fade" id="addgenresModal" tabindex="-1" role="dialog"
                        aria-labelledby="addgenresModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addgenresModalLabel">Add genres Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Add genres Information -->
                                    <form id="addgenresForm" method="post">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" id="name" name="name" required>
                                        </div>
                                        <button type="submit" name="add" class="btn btn-primary mt-2">Add genres</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit genres Modal -->
                    <div class="modal fade" id="editgenresModal" tabindex="-1" role="dialog"
                        aria-labelledby="editgenresModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editgenresModalLabel">Edit genres Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Edit genres Information -->
                                    <form id="editgenresForm">
                                        <input type="hidden" id="editgenresId" name="id">
                                        <div class="form-group">
                                            <label for="editName">Name</label>
                                            <input type="text" class="form-control" id="editName" name="name" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delete Confirmation Modal -->
                    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog"
                        aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to delete this record?</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-danger" id="deletegenresBtn">Delete</button>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Table to display genres records -->
                    <div class="container mt-4">
                        <table class="table" id="genres-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
            <!-- footer -->
            <?php include 'footer.php'; ?>
            <!-- footer end -->
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
 <!-- js -->
 <?php include 'jsScripts.php'; ?>
        <!-- js end -->

        <script>
    $.ajax({
        method:"GET",
        url:"./server/genresCrud.php",
        dataType:"json",
        success:function(response){
            $('#genres-table tbody').empty();
            response.forEach(function(genres){
                $('#genres-table tbody').append(
                    `<tr>
                        <td>${genres.id}</td>
                        <td>${genres.name}</td>
                        <td>
                            <button type="button" class="btn btn-sm btn-primary editgenresBtn" data-id="${genres.id}"
                                data-name="${genres.name}">Edit</button>
                            <button type="button" class="btn btn-sm btn-danger deletegenresBtn"
                                data-id="${genres.id}">Delete</button>
                        </td>
                    </tr>`
                );
            });
        }
    });
</script>
    <script>
        $(document).ready(function () {


            // Add genres Form Submission
            $('#addgenresForm').submit(function (event) {
                event.preventDefault();
                const name = $('#name').val();
                console.log('Add genres Information:', name);
                $.ajax({
                    method:"POST",
                    url:"./server/genresCrud.php",
                    data:{
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#addgenresModal').modal('hide');
                        location.reload();
                    }
                });
                
            });


            // Edit genres Form Submission
            $('#editgenresForm').submit(function (event) {
                event.preventDefault();
                const id = $('#editgenresId').val();
                const name = $('#editName').val();
                console.log('Edit genres Information:', { id, name });
                $.ajax({
                    method:"POST",
                    url:"./server/genresCrud.php",
                    data:{
                        id:id,
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#editgenresModal').modal('hide');
                        location.reload();
                    }
                });
                
            });

            // Open Edit genres Modal and pre-fill data
            $(document).on('click','.editgenresBtn',function(){
                const id = $(this).data('id');
                const name = $(this).data('name');
                $('#editgenresId').val(id);
                $('#editName').val(name);
                $('#editgenresModal').modal('show');
            });

            // Open Delete Confirmation Modal
            $(document).on('click','.deletegenresBtn',function(){
                const id = $(this).data('id');
                $('#deletegenresBtn').data('id', id);
                $('#deleteConfirmationModal').modal('show');
            });

            // Delete genres Data
            $('#deletegenresBtn').click(function () {
                const id = $(this).data('id');
                console.log('Delete genres Information:', id);
                $.ajax({
                    method:"POST",
                    url:"./server/genresCrud.php",
                    data:{
                        id:id
                    },
                    dataType:"json",
                    success:function(response){
                        $('#deleteConfirmationModal').modal('hide');
                        location.reload();
                    }
                });
               
            });

        });
    </script>
</body>

</html>
<?php
}else{
    header("Location:LoginPage.php");
}?>