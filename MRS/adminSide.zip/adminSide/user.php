<?php 
session_start();
if(isset($_SESSION['admin_logged_in'])){
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <!-- headLinks -->
    <?php include 'headLinks.php'; ?>
    <!-- headLinks end -->
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- sidebar end-->
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <!-- navbar -->
                <?php include 'navbar.php'; ?>
                <!-- navbar end -->
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">USERS</h3>
                    </div>


                    <!-- Table to display language records -->
                    <div class="container mt-4">
                        <table class="table" id="user-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>EMAIL</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "";
                                    $dbname = "mrc";
                                    
                                    $conn = new mysqli($servername, $username, $password, $dbname);
                                    $sql="select * from users";
                                    $res =mysqli_query($conn,$sql);
                                    // print_r($res);
                                    $i=1;
                                    foreach($res as $r){
                                        
                                        echo"<tr>
                                        <td>".$i++."</td>
                                        <td>" .$r["username"]."</td>
                                        <td>".$r["email"]."</td>
                                    </tr>";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- footer -->
            <?php include 'footer.php'; ?>
            <!-- footer end -->
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
       <!-- js -->
       <?php include 'jsScripts.php'; ?>
        <!-- js end -->

 
</body>
</html>
<?php
}else{
    header("Location:LoginPage.php");
}?>