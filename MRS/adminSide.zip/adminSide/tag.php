<?php 
session_start();
if(isset($_SESSION['admin_logged_in'])){
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <!-- headLinks -->
    <?php include 'headLinks.php'; ?>
    <!-- headLinks end -->
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- sidebar end-->
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <!-- navbar -->
                <?php include 'navbar.php'; ?>
                <!-- navbar end -->
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">TAG</h3>
                    </div>
                    <!-- Add Button to open the Add tag Modal -->
                    <div class="container mt-4 " >
                        <button type="button" class="btn btn-primary " data-bs-toggle="modal"
                            data-bs-target="#addtagModal">
                            Add tag
                        </button>
                    </div>

                    <!-- Add tag Modal -->
                    <div class="modal fade" id="addtagModal" tabindex="-1" role="dialog"
                        aria-labelledby="addtagModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addtagModalLabel">Add tag Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Add tag Information -->
                                    <form id="addtagForm" method="post">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" id="name" name="name" required>
                                        </div>
                                        <button type="submit" name="add" class="btn btn-primary mt-2">Add tag</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit tag Modal -->
                    <div class="modal fade" id="edittagModal" tabindex="-1" role="dialog"
                        aria-labelledby="edittagModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="edittagModalLabel">Edit tag Information</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Form to Edit tag Information -->
                                    <form id="edittagForm">
                                        <input type="hidden" id="edittagId" name="id">
                                        <div class="form-group">
                                            <label for="editName">Name</label>
                                            <input type="text" class="form-control" id="editName" name="name" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delete Confirmation Modal -->
                    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog"
                        aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
                        <!-- Modal content... -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to delete this record?</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-danger" id="deletetagBtn">Delete</button>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Table to display tag records -->
                    <div class="container mt-4">
                        <table class="table" id="tag-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                               
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
            <!-- footer -->
            <?php include 'footer.php'; ?>
            <!-- footer end -->
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
        <!-- js -->
        <?php include 'jsScripts.php'; ?>
        <!-- js end -->
<script>
    $.ajax({
        method:"GET",
        url:"./server/tagCrud.php",
        dataType:"json",
        success:function(response){
            $('#tag-table tbody').empty();
            response.forEach(function(tag){
                $('#tag-table tbody').append(
                    `<tr>
                                    <td>${tag.id}</td>
                                    <td>${tag.name}</td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary edittagBtn" data-id="${tag.id}"
                                            data-name="${tag.name}">Edit</button>
                                        <button type="button" class="btn btn-sm btn-danger deletetagBtn"
                                            data-id="${tag.id}">Delete</button>
                                    </td>
                                </tr>`
                );
            });
        }
    });
</script>
    <script>
        $(document).ready(function () {


            // Add tag Form Submission
            $('#addtagForm').submit(function (event) {
                event.preventDefault();
                const name = $('#name').val();
                console.log('Add tag Information:', name);
                $.ajax({
                    method:"POST",
                    url:"./server/tagCrud.php",
                    data:{
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#addtagModal').modal('hide');
                        location.reload();
                    }
                });
                
            });


            // Edit tag Form Submission
            $('#edittagForm').submit(function (event) {
                event.preventDefault();
                const id = $('#edittagId').val();
                const name = $('#editName').val();
                console.log('Edit tag Information:', { id, name });
                $.ajax({
                    method:"POST",
                    url:"./server/tagCrud.php",
                    data:{
                        id:id,
                        name:name
                    },
                    dataType:"json",
                    success:function(response){
                        $('#edittagModal').modal('hide');
                        location.reload();
                    }
                });
                
            });

            // Open Edit tag Modal and pre-fill data
            $(document).on('click','.edittagBtn',function(){
                const id = $(this).data('id');
                const name = $(this).data('name');
                $('#edittagId').val(id);
                $('#editName').val(name);
                $('#edittagModal').modal('show');
            });

            // Open Delete Confirmation Modal
            $(document).on('click','.deletetagBtn',function(){
                const id = $(this).data('id');
                $('#deletetagBtn').data('id', id);
                $('#deleteConfirmationModal').modal('show');
            });

            // Delete tag Data
            $('#deletetagBtn').click(function () {
                const id = $(this).data('id');
                console.log('Delete tag Information:', id);
                $.ajax({
                    method:"POST",
                    url:"./server/tagCrud.php",
                    data:{
                        id:id
                    },
                    dataType:"json",
                    success:function(response){
                        $('#deleteConfirmationModal').modal('hide');
                        location.reload();
                    }
                });
                
            });

        });
    </script>
</body>

</html>
<?php
}else{
    header("Location:LoginPage.php");
}?>