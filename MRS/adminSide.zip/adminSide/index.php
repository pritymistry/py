<?php 
session_start();
if(isset($_SESSION['admin_logged_in'])){
    $servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$allCastSql = "select * from casts";
$allCastFetch = mysqli_query($conn, $allCastSql);
$allCast = mysqli_num_rows($allCastFetch);
// echo "<h1>total cast : ".$allCast."</h1>";

$allCategorySql = "select * from categories";
$allCategoryFetch = mysqli_query($conn, $allCategorySql);
$allCategory = mysqli_num_rows($allCategoryFetch);
// echo "<h1>total category : ".$allCategory."</h1>";


$allDirectorSql = "select * from directors";
$allDirectorFetch = mysqli_query($conn, $allDirectorSql);
$allDirector = mysqli_num_rows($allDirectorFetch);
// echo "<h1>total director : ".$allDirector."</h1>";

$allGenresSql = "select * from genres";
$allGenresFetch = mysqli_query($conn, $allGenresSql);
$allGenres =  mysqli_num_rows($allGenresFetch);
// echo "<h1>total genres : ".$allGenres."</h1>";

$allLanguagesSql = "select * from languages";
$allLanguagesFetch = mysqli_query($conn, $allLanguagesSql);
$allLanguages = mysqli_num_rows($allLanguagesFetch);
// echo "<h1>total languages : ".$allLanguages."</h1>";

$allTagsSql = "select * from tags";
$allTagsFetch = mysqli_query($conn, $allTagsSql);
$allTags = mysqli_num_rows($allTagsFetch);
// echo "<h1>total tags : ".$allTags."</h1>";

$allWritersSql = "select * from writers";
$allWritersFetch = mysqli_query($conn, $allWritersSql);
$allWriters = mysqli_num_rows($allWritersFetch);
// echo "<h1>total writers : ".$allWriters."</h1>";

$allMoviesSql = "select * from movies";
$allMoviesFetch = mysqli_query($conn, $allWritersSql);
$allMovies = mysqli_num_rows($allMoviesFetch);
// echo "<h1>total Movies : ".$allMovies."</h1>";

$allUsersSql = "select * from users";
$allUsersFetch = mysqli_query($conn, $allUsersSql);
$allUsers = mysqli_num_rows($allUsersFetch);
// echo "<h1>total Users : ".$allUsers."</h1>";
?>


<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <!-- headLinks -->
    <?php include 'headLinks.php'; ?>
    <!-- headLinks end -->
</head>

<body id="page-top">
    <div id="wrapper">

    <!-- sidebar -->
        <?php include 'sidebar.php'; ?>
    <!-- sidebar end-->


        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <!-- navbar -->
<?php include 'navbar.php'; ?>
                <!-- navbar end -->
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">Dashboard</h3>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-primary py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>Casts</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allCast; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-success py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>categorires</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allCategory; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-warning fw-bold text-xs mb-1"><span>directors</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allDirector; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-primary py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>genres</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allGenres; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-success py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>languages</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allLanguages; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-warning fw-bold text-xs mb-1"><span>movie</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allMovies; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-primary py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>tags</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allTags; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-success py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>users</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allUsers; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-xl-3 mb-4">
                                <div class="card shadow border-start-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col me-2">
                                                <div class="text-uppercase text-warning fw-bold text-xs mb-1"><span>writers</span></div>
                                                <div class="text-dark fw-bold h5 mb-0"><span><?php echo $allWriters; ?></span></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
            <!-- footer -->
            <?php include 'footer.php'; ?>
            <!-- footer end -->
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>
<?php
}else{
    header("Location:LoginPage.php");
}?>