<nav class="navbar align-items-start sidebar sidebar-dark accordion bg-gradient-danger p-0 navbar-dark">
    <div class="container-fluid d-flex flex-column p-0">
        <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="index.php">
            <div class="sidebar-brand-icon ">
                <i class="fas fa-film"></i>
            </div>
            <div class="sidebar-brand-text mx-3"><span>MRS</span> </div>
        </a>
        <hr class="sidebar-divider my-0">
        <ul class="navbar-nav text-light" id="accordionSidebar">
            <li class="nav-item"><a class="nav-link active" href="index.php"><span>Dashboard</span></a></li>
            <li class="nav-item"><a class="nav-link" href="cast.php"><span>Cast</span></a></li>
            <li class="nav-item"><a class="nav-link" href="category.php"><span>Category</span></a></li>
            <li class="nav-item"><a class="nav-link" href="director.php"><span>Director</span></a></li>
            <li class="nav-item"><a class="nav-link" href="genres.php"><span>Genres</span></a></li>
            <li class="nav-item"><a class="nav-link" href="languages.php"><span>Language</span></a></li>
            <li class="nav-item"><a class="nav-link" href="movie.php"><span>Movie</span></a></li>
            <!-- <li class="nav-item"><a class="nav-link" href="review.php"><span>Review</span></a></li> -->
            <li class="nav-item"><a class="nav-link" href="tag.php"><span>Tag</span></a></li>
            <li class="nav-item"><a class="nav-link" href="user.php"><span>User</span></a></li>
            <!-- <li class="nav-item"><a class="nav-link" href="wishlist.php"><span>Wishlist</span></a></li> -->
            <li class="nav-item"><a class="nav-link" href="writer.php"><span>Writer</span></a></li>
        </ul>
        <div class="text-center d-none d-md-inline">
            <button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button>
        </div>
    </div>
</nav>