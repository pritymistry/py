<?php
session_start();

// Check if user is already logged in
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
  // Redirect to admin dashboard or any other page
  header("Location: index.php");
  exit;
}

// Check if the login form is submitted
if (isset($_POST['login'])) {
  $username = "admin"; // Replace with your actual admin username
  $password = "password"; // Replace with your actual admin password

  $input_username = $_POST['username'];
  $input_password = $_POST['password'];

  // Verify the admin credentials
  if ($input_username === $username && $input_password === $password) {
    // Set admin session
    $_SESSION['admin_logged_in'] = true;

    // Redirect to admin dashboard or any other page
    header("Location: index.php");
    exit;
  } else {
    $error = "Invalid username or password.";
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Login - Admin Panel</title>
  <link rel="stylesheet" href="./assets/bootstrap/css/style.css">
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-4 offset-md-4 mt-5">
        <h2 class="text-center">Admin Login</h2>
        <form method="POST">
          <?php if (isset($error)) { ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
          <?php } ?>
          <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
          </div>
          <button type="submit" name="login" class="btn btn-primary btn-block">Login</button>
        </form>
      </div>
    </div>
  </div>
</body>

</html>