<?php
session_start();
if (isset($_SESSION['admin_logged_in'])) {
?>
    <!DOCTYPE html>
    <html data-bs-theme="light" lang="en">

    <head>
        <!-- headLinks -->
        <?php include 'headLinks.php'; ?>
        <!-- headLinks end -->
    </head>

    <body id="page-top">
        <div id="wrapper">


            <!-- sidebar -->
            <?php include 'sidebar.php'; ?>
            <!-- sidebar end-->

            <div class="d-flex flex-column" id="content-wrapper">
                <div id="content">
                    <!-- navbar -->
                    <?php include 'navbar.php'; ?>
                    <!-- navbar end -->
                    <div class="container-fluid">
                        <div class="d-sm-flex justify-content-between align-items-center mb-4">
                            <h3 class="text-dark mb-0">CAST</h3>
                        </div>
                        <!-- Add Button for Add Cast Modal -->
                        <div class="container mt-4 ">
                            <button type="button" class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#addCastModal">
                                Add Cast
                            </button>
                        </div>

                        <!-- Add Cast Modal -->
                        <div class="modal fade" id="addCastModal" tabindex="-1" role="dialog" aria-labelledby="addCastModalLabel" aria-hidden="true">
                            <!-- Modal content... -->
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addCastModalLabel">Add Cast Information</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Form to Add Cast Information -->
                                        <form id="addCastForm" method="post">
                                            <div class="form-group">
                                                <label for="name">Name</label>
                                                <input type="text" class="form-control" id="name" name="name" required>
                                            </div>
                                            <button type="submit" name="add" class="btn btn-primary mt-2">Add Cast</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Edit Cast Modal -->
                        <div class="modal fade" id="editCastModal" tabindex="-1" role="dialog" aria-labelledby="editCastModalLabel" aria-hidden="true">
                            <!-- Modal content... -->
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editCastModalLabel">Edit Cast Information</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Form to Edit Cast Information -->
                                        <form id="editCastForm">
                                            <input type="hidden" id="editCastId" name="id">
                                            <div class="form-group">
                                                <label for="editName">Name</label>
                                                <input type="text" class="form-control" id="editName" name="name" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Delete Confirmation Modal -->
                        <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
                            <!-- Modal content... -->
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Are you sure you want to delete this record?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="button" class="btn btn-danger" id="deleteCastBtn">Delete</button>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- Table to display cast records -->
                        <div class="container mt-4">
                            <table class="table" id="cast-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <!-- <tr>
                                    <td>1</td>
                                    <td>John Doe</td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary editCastBtn" data-id="1"
                                            data-name="John Doe">Edit</button>
                                        <button type="button" class="btn btn-sm btn-danger deleteCastBtn"
                                            data-id="1">Delete</button>
                                    </td>
                                </tr> -->
                                    <!-- Add more rows as needed -->
                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>
                <!-- footer -->
                <?php include 'footer.php'; ?>
                <!-- footer end -->
            </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
        </div>
        <!-- js -->
        <?php include 'jsScripts.php'; ?>
        <!-- js end -->

        <script>
            $.ajax({
                method: "GET",
                url: "./server/castcrud.php",
                data: {},
                dataType: "json",
                success: function(response) {
                    $('#cast-table tbody').empty();
                    response.forEach(function(cast) {
                        const fullName = cast.name;
                        $('#cast-table tbody').append(`
                                <tr>
                                    <td>${cast.id}</td>
                                    <td>${fullName}</td>
                                    <td>
                                        <button type="button"  class="btn btn-sm btn-primary editCastBtn" data-id=${cast.id}
                                        data-name="${fullName}">Edit</button>
                                        <button type="button" class="btn btn-sm btn-danger deleteCastBtn"
                                            data-id=${cast.id}>Delete</button>
                                    </td>
                                    <!-- Add more columns as needed -->
                                </tr>
                            `);
                    });
                }
            });
        </script>

        <script>
            $(document).ready(function() {
                let name = '';
                let id = null;


                // Add Cast Form Submission
                $('#addCastForm').submit(function(event) {
                    event.preventDefault();
                    name = $('#name').val();
                    console.log('Add Cast Information:', name);

                    $.ajax({
                        method: "POST",
                        url: "./server/castcrud.php",
                        data: {
                            name: name
                        },
                        dataType: "json",
                        success: function(response) {
                            $('#addCastModal').modal('hide');
                            location.reload();

                        }
                    });
                });

                // Open Edit Cast Modal with data
                $(document).on('click', '.editCastBtn', function() {
                    id = $(this).data('id');
                    name = $(this).data('name');
                    $('#editCastId').val(id);
                    $('#editName').val(name);
                    $('#editCastModal').modal('show');
                    console.log("edit Clicked");
                });

                // Edit Cast Form Submission
                $('#editCastForm').submit(function(event) {
                    event.preventDefault();
                    id = $('#editCastId').val();
                    name = $('#editName').val();

                    $.ajax({
                        method: "POST",
                        url: "./server/castcrud.php",
                        data: {
                            id: id,
                            name: name
                        },
                        dataType: "json",
                        success: function(response) {
                            $('#editCastModal').modal('hide');
                            location.reload();

                        }
                    });
                });


                // Open Delete Confirmation Modal
                $(document).on('click', '.deleteCastBtn', function() {
                    id = $(this).data('id');
                    $('#deleteCastBtn').data('id', id);
                    $('#deleteConfirmationModal').modal('show');
                });

                // Delete Cast Data
                $('#deleteCastBtn').click(function() {
                    id = $(this).data('id');

                    $.ajax({
                        method: "POST",
                        url: "./server/castcrud.php",
                        data: {
                            id: id
                        },
                        dataType: "json",
                        success: function(response) {
                            $('#deleteConfirmationModal').modal('hide');
                            location.reload();
                        }
                    });
                });

            });
        </script>

    </body>

    </html>
<?php
} else {
    header("Location:LoginPage.php");
} ?>