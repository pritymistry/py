<?php
include 'connection.php';
// Handle Delete Operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && isset($_POST["dataAction"]) === "delete") {
    $id = $_POST["id"];

    // Perform SQL delete query to delete the cast member
    $sql = "DELETE FROM categories WHERE id = $id";
    echo "sql : " . $sql;
    // Execute the query
    $result = mysqli_query($connection, $sql);

    // Check if the query was successful and return a response
    if ($result) {
        $response = ["message" => "categories member deleted successfully"];
    } else {
        $response = ["error" => "Failed to delete categories member"];
    }

    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
// Handle Create (Add) Operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["name"]) && !isset($_POST["id"])) {
    $name = mysqli_real_escape_string($connection, $_POST["name"]);

    // Perform SQL insert query to add the cast member to the database
    $sql = "INSERT INTO categories (name) VALUES ('$name')";

    // Execute the query
    $result = mysqli_query($connection, $sql);

    // Check if the query was successful and return a response
    if ($result) {
        $response = ["message" => "categories added successfully"];
    } else {
        $response = ["error" => "Failed to add categories"];
    }

    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}

// Handle Read (Retrieve) Operation - Retrieve all cast members
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    // Perform SQL select query to retrieve all cast members
    $sql = "SELECT * FROM categories";

    // Execute the query
    $result = mysqli_query($connection, $sql);

    // Initialize an array to store the retrieved cast data
    $categoriesData = [];

    // Fetch each row from the result set
    while ($row = mysqli_fetch_assoc($result)) {
        $categoriesData[] = $row;
    }

    // Return the cast data as JSON
    header("Content-Type: application/json");
    $response = $categoriesData;
    echo json_encode($categoriesData);
    exit();
}

// Handle Update Operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && isset($_POST["name"])) {
    $id = $_POST["id"];
    $name = mysqli_real_escape_string($connection, $_POST["name"]);

    // Perform SQL update query to update the cast member's name
    $sql = "UPDATE categories SET name = '$name' WHERE id = $id";

    // Execute the query
    $result = mysqli_query($connection, $sql);

    // Check if the query was successful and return a response
    if ($result) {
        $response = ["message" => "categories member updated successfully"];
    } else {
        $response = ["error" => "Failed to update categories member"];
    }

    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}


// If none of the above conditions were met, return an error response
$response = ["error" => "Invalid request"];
header("Content-Type: application/json");
echo json_encode($response);
exit();
