<?php
include 'connection.php';

//add opration 
if($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST["name"]) && !isset($_POST["id"])){
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    $sql="insert into genres(name) values('$name')";
    $result=mysqli_query($connection,$sql);
    if($result){
        $response=["message" => "director added successfully."];
    }else{
        $response=["mesage"=>"fail to add director."];
    }
    header("Content-Type:application/json");
    $response=["mesage"=>"fail to add director."];
    echo json_encode($response);
    exit();
}   
//reading all data
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $sql = "SELECT * FROM genres";
    $result = mysqli_query($connection, $sql);
    $genresData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $genresData[] = $row;
    }
    header("Content-Type: application/json");
    $response = $genresData;
    echo json_encode($genresData);
    exit();
}
//delete opration
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && !isset($_POST["name"])) {
    $id = $_POST["id"];
     $sql = "DELETE FROM genres WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "genres deleted successfully"];
    } else {
        $response = ["error" => "Failed to delete genres"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
//update operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && isset($_POST["name"])) {
    $id = $_POST["id"];
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    $sql = "UPDATE genres SET name = '$name' WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "genres updated successfully"];
    } else {
        $response = ["error" => "Failed to update genres"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
?>