<?php
include 'connection.php';

//add opration 
if($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST["name"]) && !isset($_POST["id"])){
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    $sql="insert into languages(name) values('$name')";
    $result=mysqli_query($connection,$sql);
    if($result){
        $response=["message" => "director added successfully."];
    }else{
        $response=["mesage"=>"fail to add director."];
    }
    header("Content-Type:application/json");
    $response=["mesage"=>"fail to add director."];
    echo json_encode($response);
    exit();
}   
//reading all data
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $sql = "SELECT * FROM languages";
    $result = mysqli_query($connection, $sql);
    $languagesData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $languagesData[] = $row;
    }
    header("Content-Type: application/json");
    $response = $languagesData;
    echo json_encode($languagesData);
    exit();
}
//delete opration
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && !isset($_POST["name"])) {
    $id = $_POST["id"];
     $sql = "DELETE FROM languages WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "languages deleted successfully"];
    } else {
        $response = ["error" => "Failed to delete languages"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
//update operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && isset($_POST["name"])) {
    $id = $_POST["id"];
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    $sql = "UPDATE languages SET name = '$name' WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "languages updated successfully"];
    } else {
        $response = ["error" => "Failed to update languages"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
?>