<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "<pre>";
print_r($_POST);
echo "</pre>";
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $cast = $_POST["cast"];
    $category = $_POST["category"];
    $director = $_POST["director"];
    $genres = $_POST["genres"];
    $languages = $_POST["languages"];
    $tags = $_POST["tags"];
    $writers = $_POST["writers"];
    $movie_id = $_POST["id"];

    //checkk if movie id is present in movie table or not
    $sql = "SELECT * FROM movies WHERE id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie table";
    } else {
        echo "movie id is not present in movie table";
        exit();
    }

    //check if any data in movie_has_casts, movie_has_categories, movie_has_director, movie_has_genres, movie_has_languages, movie_has_tags, movie_has_writers table is present or not for that movie id if present then delete that data from that table for that movie id and then insert new data
    $sql = "SELECT * FROM movie_has_casts WHERE movie_id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie_has_casts table";
        $sql = "DELETE FROM movie_has_casts WHERE movie_id=$movie_id";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "movie id is not present in movie_has_casts table";
    }
    $sql = "SELECT * FROM movie_has_categories WHERE movie_id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie_has_categories table";
        $sql = "DELETE FROM movie_has_categories WHERE movie_id=$movie_id";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "movie id is not present in movie_has_categories table";
    }
    $sql = "SELECT * FROM movie_has_director WHERE movie_id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie_has_director table";
        $sql = "DELETE FROM movie_has_director WHERE movie_id=$movie_id";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "movie id is not present in movie_has_director table";
    }
    $sql = "SELECT * FROM movie_has_genres WHERE movie_id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie_has_genres table";
        $sql = "DELETE FROM movie_has_genres WHERE movie_id=$movie_id";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "movie id is not present in movie_has_genres table";
    }
    $sql = "SELECT * FROM movie_has_languages WHERE movie_id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie_has_languages table";
        $sql = "DELETE FROM movie_has_languages WHERE movie_id=$movie_id";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "movie id is not present in movie_has_languages table";
    }
    $sql = "SELECT * FROM movie_has_tags WHERE movie_id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie_has_tags table";
        $sql = "DELETE FROM movie_has_tags WHERE movie_id=$movie_id";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "movie id is not present in movie_has_tags table";
    }
    $sql = "SELECT * FROM movie_has_writers WHERE movie_id=$movie_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "movie id is present in movie_has_writers table";
        $sql = "DELETE FROM movie_has_writers WHERE movie_id=$movie_id";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "movie id is not present in movie_has_writers table";
    }


    foreach ($cast as $key => $value) {
        echo $value . "cast id" . "<br>";
        $sql = "INSERT INTO movie_has_casts(movie_id,cast_id) VALUES ($movie_id,$value)";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "New record created successfully CAST";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }
    //do above for all tables
    foreach ($category as $key => $value) {
        echo $value . "category id" . "<br>";
        $sql = "INSERT INTO movie_has_categories(movie_id,category_id) VALUES ($movie_id,$value)";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "New record created successfully CATEEGORY";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }
    foreach ($director as $key => $value) {
        echo $value . "director id" . "<br>";
        $sql = "INSERT INTO movie_has_director(movie_id,director_id) VALUES ($movie_id,$value)";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "New record created successfully DIRECTOR";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }
    foreach ($genres as $key => $value) {
        echo $value . "genres id" . "<br>";
        $sql = "INSERT INTO movie_has_genres(movie_id,genre_id) VALUES ($movie_id,$value)";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "New record created successfully GENRES";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }
    foreach ($languages as $key => $value) {
        echo $value . "languages id" . "<br>";
        $sql = "INSERT INTO movie_has_languages(movie_id,language_id) VALUES ($movie_id,$value)";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "New record created successfully LANGUAGES";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }
    foreach ($tags as $key => $value) {
        echo $value . "tags id" . "<br>";
        $sql = "INSERT INTO movie_has_tags(movie_id,tag_id) VALUES ($movie_id,$value)";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "New record created successfully TAGS";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }
    foreach ($writers as $key => $value) {
        echo $value . "writers id" . "<br>";
        $sql = "INSERT INTO movie_has_writers(movie_id,writer_id) VALUES ($movie_id,$value)";
        $result = $conn->query($sql);
        if ($result === TRUE) {
            echo "New record created successfully WRITERS";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }


    return $response = ["message : " + "data inserted successfully"];
    exit();
}
