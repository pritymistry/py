<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["name"]) && isset($_POST["description"]) && isset($_POST["date"])  && !isset($_POST["id"]) && $_POST["crud_type"] === "add") {
    $image = $_FILES["file"];
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);
    $date = $_POST["date"];


    if (0 < $_FILES['file']['error']) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    } else {
        $image_name = basename($image["name"]);
        //add random number and time to image name to avoid duplicate names
        $image_name = rand(1000, 1000000) . time() . $image_name;
        $image_path = "uploads/" . $image_name;
        // move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/' . $_FILES['file']['name']);
        move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/' . $image_name);
        $sql = "INSERT INTO movies (title, description, release_date, image_url) VALUES ('$name', '$description', '$date', '$image_path')";
        if ($conn->query($sql) === TRUE) {
            return  $response = ["message" => "Movie added successfully."];
        } else {
            return $response = ["message" => "Failed to add movie."];
        }
    }
    exit();
}

//handle update
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["name"]) && isset($_POST["description"]) && isset($_POST["date"])  && isset($_POST["id"]) && $_POST["crud_type"] === "edit") {
    $image = $_FILES["file"];
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);
    $date = $_POST["date"];
    $id = $_POST["id"];

    if (0 < $_FILES['file']['error']) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    } else {
        $image_name = basename($image["name"]);
        $image_name = rand(1000, 1000000) . time() . $image_name;
        $image_path = "uploads/" . $image_name;
        // move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/' . $_FILES['file']['name']);
        move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/' . $image_name);


        // make image optional in update
        if ($image_name == "") {
            $sql = "UPDATE movies SET title='$name', description='$description', release_date='$date' WHERE id=$id";
            if ($conn->query($sql) === TRUE) {
                return  $response = ["message" => "Movie updated successfully."];
            } else {
                return $response = ["message" => "Failed to update movie."];
            }
        } else {
            $sql = "UPDATE movies SET title='$name', description='$description', release_date='$date', image_url='$image_path' WHERE id=$id";
            if ($conn->query($sql) === TRUE) {
                return  $response = ["message" => "Movie updated successfully."];
            } else {
                return $response = ["message" => "Failed to update movie."];
            }
        }

        // // $sql = "UPDATE movies SET title='$name', description='$description', release_date='$date', image_url='$image_path' WHERE id=$id";
        // if ($conn->query($sql) === TRUE) {
        //     return  $response = ["message" => "Movie updated successfully."];
        // } else {
        //     return $response = ["message" => "Failed to update movie."];
        // }
    }
    exit();
}



// Handle Delete Operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && $_POST["crud_type"] === "delete") {
    $id = $_POST["id"];

    //delete image from uploads folder
    $sql = "SELECT * FROM movies WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $image_path = $row["image_url"];
    unlink($image_path);

    // Perform SQL delete query to delete the movies
    $sql = "DELETE FROM movies WHERE id = $id";

    // Execute the query
    $result = mysqli_query($conn, $sql);

    // Check if the query was successful and return a response
    if ($result) {
        $response = ["message" => "movies deleted successfully"];
    } else {
        $response = ["error" => "Failed to delete movies"];
    }

    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $sql = "select * from movies";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $movieData = [];

        // Fetch each row from the result set
        while ($row = mysqli_fetch_assoc($result)) {
            $movieData[] = $row;
        }

        // Return the cast data as JSON
        header("Content-Type: application/json");
        $response = $movieData;
        echo json_encode($movieData);
        exit();
    } else {
        return  $response = ["message" => "Failed."];
    }
}


// <!-- details for movie  -->
//                     <div class="modal fade" id="detailsMovieModel" tabindex="-1" role="dialog" aria-labelledby="detailsMovieModelLabel" aria-hidden="true">
//                         <!-- Modal content... -->
//                         <div class="modal-dialog" role="document">
//                             <div class="modal-content">
//                                 <div class="modal-header">
//                                     <h5 class="modal-title" id="detailsMovieModelLabel">Confirm Details</h5>
//                                     <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
//                                         <span aria-hidden="true">&times;</span>
//                                     </button>
//                                 </div>
//                                 <div class="modal-body">
//                                     <p>Are you sure you want to delete this record?</p>
//                                 </div>
//                                 <div class="modal-footer">
//                                     <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
//                                     <button type="button" class="btn btn-danger" id="detailsMovieBtn">add</button>
//                                 </div>
//                             </div>
//                         </div>

//                     </div>