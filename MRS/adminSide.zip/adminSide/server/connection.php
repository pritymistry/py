<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);
?>