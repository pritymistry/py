<?php
// Include any necessary database configuration or connection setup here

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);

// Handle Create (Add) Operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["name"]) && !isset($_POST["id"])) {
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    
    // Perform SQL insert query to add the cast member to the database
     $sql = "INSERT INTO casts (name) VALUES ('$name')";
    
    // Execute the query
     $result = mysqli_query($connection, $sql);
    
    // Check if the query was successful and return a response
    if ($result) {
        $response = ["message" => "Cast member added successfully"];
    } else {
        $response = ["error" => "Failed to add cast member"];
    }
    
    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}

// Handle Update Operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && isset($_POST["name"])) {
    $id = $_POST["id"];
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    
    // Perform SQL update query to update the cast member's name
    $sql = "UPDATE casts SET name = '$name' WHERE id = $id";
    
    // Execute the query
    $result = mysqli_query($connection, $sql);
    
    // Check if the query was successful and return a response
    if ($result) {
        $response = ["message" => "Cast member updated successfully"];
    } else {
        $response = ["error" => "Failed to update cast member"];
    }
    
    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}

// Handle Delete Operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"])) {
    $id = $_POST["id"];
    
    // Perform SQL delete query to delete the cast member
     $sql = "DELETE FROM casts WHERE id = $id";
    
    // Execute the query
    $result = mysqli_query($connection, $sql);
    
    // Check if the query was successful and return a response
    if ($result) {
        $response = ["message" => "Cast member deleted successfully"];
    } else {
        $response = ["error" => "Failed to delete cast member"];
    }
    
    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}

// Handle Read (Retrieve) Operation - Retrieve all cast members
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    // Perform SQL select query to retrieve all cast members
    $sql = "SELECT * FROM casts";
    
    // Execute the query
    $result = mysqli_query($connection, $sql);
    
    // Initialize an array to store the retrieved cast data
    $castData = [];
    
    // Fetch each row from the result set
    while ($row = mysqli_fetch_assoc($result)) {
        $castData[] = $row;
    }
    
    // Return the cast data as JSON
    header("Content-Type: application/json");
    $response = $castData;
    echo json_encode($castData);
    exit();
}

// Handle Read (Retrieve) Operation - Not shown in this example

// If none of the above conditions were met, return an error response
$response = ["error" => "Invalid request"];
header("Content-Type: application/json");
echo json_encode($response);
exit();
?>






