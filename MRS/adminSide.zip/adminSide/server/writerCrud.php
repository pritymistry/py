<?php
include 'connection.php';

//add opration 
if($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST["name"]) && !isset($_POST["id"])){
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    $sql="insert into writers(name) values('$name')";
    $result=mysqli_query($connection,$sql);
    if($result){
        $response=["message" => "director added successfully."];
    }else{
        $response=["mesage"=>"fail to add director."];
    }
    header("Content-Type:application/json");
    $response=["mesage"=>"fail to add director."];
    echo json_encode($response);
    exit();
}   
//reading all data
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $sql = "SELECT * FROM writers";
    $result = mysqli_query($connection, $sql);
    $writersData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $writersData[] = $row;
    }
    header("Content-Type: application/json");
    $response = $writersData;
    echo json_encode($writersData);
    exit();
}
//delete opration
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && !isset($_POST["name"])) {
    $id = $_POST["id"];
     $sql = "DELETE FROM writers WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "writers deleted successfully"];
    } else {
        $response = ["error" => "Failed to delete writers"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
//update operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && isset($_POST["name"])) {
    $id = $_POST["id"];
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    $sql = "UPDATE writers SET name = '$name' WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "writers updated successfully"];
    } else {
        $response = ["error" => "Failed to update writers"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
?>