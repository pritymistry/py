<?php
include 'connection.php';

//add opration 
if($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST["name"]) && !isset($_POST["id"])){
    $name=mysqli_real_escape_string($connection,$_POST["name"]);
    $sql="insert into directors(name) values('$name')";
    $result=mysqli_query($connection,$sql);
    if($result){
        $response=["message" => "director added successfully."];
    }else{
        $response=["mesage"=>"fail to add director."];
    }
    header("Content-Type:application/json");
    $response=["mesage"=>"fail to add director."];
    echo json_encode($response);
    exit();
}   
//reading all data
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $sql = "SELECT * FROM directors";
    $result = mysqli_query($connection, $sql);
    $directorsData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $directorsData[] = $row;
    }
    header("Content-Type: application/json");
    $response = $directorsData;
    echo json_encode($directorsData);
    exit();
}
//delete opration
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && !isset($_POST["name"])) {
    $id = $_POST["id"];
     $sql = "DELETE FROM directors WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "directors deleted successfully"];
    } else {
        $response = ["error" => "Failed to delete directors"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
//update operation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"]) && isset($_POST["name"])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $sql = "UPDATE directors SET name = '$name' WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    if ($result) {
        $response = ["message" => "directors updated successfully"];
    } else {
        $response = ["error" => "Failed to update directors"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
?>