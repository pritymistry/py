<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);

?>

<!DOCTYPE html>
<html>

<head>
  <title>Movie Recommendation System</title>
  <?php include("header.php");
  session_start();
  ?>
</head>

<body>
  <!-- nav -->
  <?php include("navbar.php"); ?>
  <!-- nav end -->


  <div class="container">
    <div class="jumbotron">
      <h1>Welcome to the Movie Recommendation System</h1>
      <p>Get personalized movie recommendations based on your preferences.</p>
    </div>

    <div class="row m-5" id="movieDetails">

      <!-- <div class="col-md-6">
        <div class="movie-card" data-toggle="modal" data-target="#movieModal2">
          <img src="movie2.jpg" alt="Movie 2" class="img-fluid" />
          <h4>Movie 2</h4>
          <p>Director: Director 2</p>
          <p>Genre: Genre 2</p>
          <p>Rating: 7.8</p>
        </div>
      </div> -->
    </div>
  </div>





  <script>
    $.ajax({
      method: "GET",
      url: "./server/movieDetails.php",
      dataType: "json",
      success: function(response) {
        $('#movieDetails').empty();
        response.forEach(function(movieDetail) {
          $('#movieDetails').append(
            ` <div class="col-md-3">
                    <div class="movie-card" data-toggle="modal" data-target="#movieModal${movieDetail.id}">
                        <img src="../adminSide/server/${movieDetail.image_url}" alt="Movie 1" class="img-fluid">
                        <hr/>
                        <h4>${movieDetail.title}</h4>
                        <p>${movieDetail.release_date}</p>
                        <p>${movieDetail.description}</p>
                    </div>
                  </div>
                  

                  <div class="modal fade" id="movieModal${movieDetail.id}" tabindex="-1" role="dialog" aria-labelledby="movieModal1Label" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="movieModal1Label">${movieDetail.title}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <img src="../adminSide/server/${movieDetail.image_url}" alt="Movie 1" class="img-fluid mb-3" />
                        <b><p>Release Date: ${movieDetail.release_date}</p>
                        <p>${movieDetail.description}</p></b>
                      </div>
                    </div>
                  </div>
                </div>
                  
                  `);
        });
      }
    });
  </script>


  <script>
    $(document).ready(function() {
      let username = "";
      let password = "";
      let email = "";
      console.log("refresh done");
      $("#signUpForm").click(function(event) {
        event.preventDefault();
        username = $("#signupName").val();
        password = $("#signupPassword").val();
        email = $("#signupEmail").val();

        //write ajax code here
        $.ajax({
          method: "POST",
          url: "./server/userCRUDSignUp.php",
          data: {
            username: username,
            password: password,
            email: email
          },
          dataType: "json",
          success: function(response) {
            console.log(response);
            if (response.success) {
              location.reload();

            } else {
              alert("Registration failed: " + response.message);
              // Handle registration failure
              console.log("Registration failed: " + response.message);
            }
            // },
            // error: function (jqXHR, textStatus, errorThrown) {
            //   // Handle AJAX request errors
            //   console.error("AJAX Error: " + textStatus, errorThrown);
            //   }




            //   success: function(response) {
            //     console.log(response);
            //     $("#registrationModal").modal("hide");
            // console.log("demo in click");


          }

        });

      });




      $("#signInForm").click(function(event) {
        event.preventDefault();

        password = $("#loginPassword").val();
        email = $("#loginEmail").val();

        //write ajax code here
        $.ajax({
          method: "POST",
          url: "./server/user-login.php",
          data: {
            email: email,
            password: password

          },
          dataType: "json",
          success: function(response) {
            console.log(response);
            if (response.success) {
              window.location.reload();
              //write js code for page reload
              console.log("login success in console");


            } else {
              alert("Login failed: " + response.message);
              // Handle registration failure
              console.log("Login failed: " + response.message);
            }
            // },
            // error: function (jqXHR, textStatus, errorThrown) {
            //   // Handle AJAX request errors
            //   console.error("AJAX Error: " + textStatus, errorThrown);
            //   }




            //   success: function(response) {
            //     console.log(response);
            //     $("#registrationModal").modal("hide");
            // console.log("demo in click");


          }

        });

      });
    });
  </script>
  <?php include("footer.php") ?>
</body>

</html>
<!-- 

            `<h3>${movieDetail.id}</h3>
            <p>${movieDetail.title},<br/> ${movieDetail.description},<br/> ${movieDetail.release_date},<br/> ${movieDetail.image_url}</p>
            <br/> ` -->