  <!-- Registration Modal -->
  <div class="modal fade" id="registrationModal" tabindex="-1" role="dialog" aria-labelledby="registrationModalLabel" aria-hidden="true">
    <!-- Modal content here (same as before) -->
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="registrationModalLabel">Sign Up</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form>
            <div class="form-group">
              <label for="signupName">Username</label>
              <input type="text" class="form-control" id="signupName" placeholder="Enter your name" />
            </div>
            <div class="form-group">
              <label for="signupEmail">Email address</label>
              <input type="email" class="form-control" id="signupEmail" placeholder="Enter your email" />
            </div>
            <div class="form-group">
              <label for="signupPassword">Password</label>
              <input type="password" class="form-control" id="signupPassword" placeholder="Enter your password" />
            </div>
            <button type="submit" class="btn btn-primary" id="signUpForm">
              Sign Up
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>