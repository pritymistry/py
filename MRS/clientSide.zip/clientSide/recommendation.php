<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ./index.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);

$cast_sql = "select * from casts";
$cast_res = mysqli_query($connection, $cast_sql);

$categories_sql = "select * from categories";
$categories_res = mysqli_query($connection, $categories_sql);

$directors_sql = "select * from directors";
$directors_res = mysqli_query($connection, $directors_sql);

$genres_sql = "select * from genres";
$genres_res = mysqli_query($connection, $genres_sql);

$languages_sql = "select * from languages";
$languages_res = mysqli_query($connection, $languages_sql);

$tags_sql = "select * from tags";
$tags_res = mysqli_query($connection, $tags_sql);

$writers_sql = "select * from writers";
$writers_res = mysqli_query($connection, $writers_sql);
if (isset($_SESSION["user_id"])) {
    $user_id = $_SESSION["user_id"];
    // getting cast data
    $sql = "SELECT * FROM user_has_cast_preference WHERE user_id=$user_id";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        // echo "user id is present in user_has_cast_preference table";
        $sql = "SELECT * FROM user_has_cast_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        $seleted_cast_id = [];
        while ($row = $result->fetch_assoc()) {
            array_push($seleted_cast_id, $row['cast_id']);
        }
        // print_r($seleted_cast_id);
    } else {
        // echo "user id is not present in user_has_cast_preference table";
    }
    //getting category data
    $sql = "SELECT * FROM user_has_category_preference WHERE user_id=$user_id";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        // echo "user id is present in user_has_category_preference table";
        $sql = "SELECT * FROM user_has_category_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        $seleted_category_id = [];
        while ($row = $result->fetch_assoc()) {
            array_push($seleted_category_id, $row['category_id']);
        }
        // print_r($seleted_category_id);
    } else {
        // echo "user id is not present in user_has_category_preference table";
    }
    //getting director data
    $sql = "SELECT * FROM user_has_directors_preference WHERE user_id=$user_id";
    $result = $connection->query($sql);

    if ($result->num_rows > 0) {
        // echo "user id is present in user_has_directors_preference table";
        $sql = "SELECT * FROM user_has_directors_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        $seleted_director_id = [];
        while ($row = $result->fetch_assoc()) {
            array_push($seleted_director_id, $row['director_id']);
        }
        // print_r($seleted_director_id);
    } else {
        // echo "user id is not present in user_has_director_preference table";
    }
    //getting genre data
    $sql = "SELECT * FROM user_has_genre_preference WHERE user_id=$user_id";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        // echo "user id is present in user_has_genre_preference table";
        $sql = "SELECT * FROM user_has_genre_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        $seleted_genre_id = [];
        while ($row = $result->fetch_assoc()) {
            array_push($seleted_genre_id, $row['genre_id']);
        }
        // print_r($seleted_genre_id);
    } else {
        // echo "user id is not present in user_has_genre_preference table";
    }
    //getting language data
    $sql = "SELECT * FROM user_has_language_preference WHERE user_id=$user_id";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        // echo "user id is present in user_has_language_preference table";
        $sql = "SELECT * FROM user_has_language_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        $seleted_language_id = [];
        while ($row = $result->fetch_assoc()) {
            array_push($seleted_language_id, $row['language_id']);
        }
        // print_r($seleted_language_id);
    } else {
        // echo "user id is not present in user_has_language_preference table";
    }
    //getting tag data
    $sql = "SELECT * FROM user_has_tags_preference WHERE user_id=$user_id";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        // echo "user id is present in user_has_tags_preference table";
        $sql = "SELECT * FROM user_has_tags_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        $seleted_tag_id = [];
        while ($row = $result->fetch_assoc()) {
            array_push($seleted_tag_id, $row['tag_id']);
        }
        // print_r($seleted_tag_id);
    } else {
        // echo "user id is not present in user_has_tags_preference table";
    }
    //getting writer data
    $sql = "SELECT * FROM user_has_writers_preference WHERE user_id=$user_id";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        // echo "user id is present in user_has_writers_preference table";
        $sql = "SELECT * FROM user_has_writers_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        $seleted_writer_id = [];
        while ($row = $result->fetch_assoc()) {
            array_push($seleted_writer_id, $row['writer_id']);
        }
        // print_r($seleted_writer_id);
    } else {
        // echo "user id is not present in user_has_writers_preference table";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
    include("header.php");
    ?>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <script src="./assets/js/code.jquery.com_jquery-3.7.1.min.js"></script> -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
</head>

<body>
    <!-- nav -->
    <?php include("navbar.php"); ?>
    <!-- nav end -->

    <!-- Registration  end -->
    <main class="container border mb-5">
        <div class="container-fulid m-3">
            <div class="row g-2">
                <div class="col-2">
                    <sidebar class="nav">
                        <!-- tags -->
                        <div class="tags-filter ">
                            <h5>Tag</h5>
                            <ul class="nav flex-column">
                                <?php
                                while ($row = mysqli_fetch_assoc($tags_res)) {

                                    $is_checked = in_array($row['id'], $seleted_tag_id ?? []) ?  "checked" : "";
                                    echo '<li class="nav-item">
                            <input type="checkbox" name="tags[]" value="' . $row['id'] . '" ' . $is_checked . '>
                            <label for="' . $row['name'] . '">' . $row['name'] . '</label>
                            </li>';
                                }
                                ?>
                            </ul>
                        </div>
                        <!-- cast -->
                        <div class="cast-filter ">
                            <h5>Cast</h5>
                            <ul class="nav flex-column">
                                <?php
                                while ($row = mysqli_fetch_assoc($cast_res)) {
                                    $is_checked = in_array($row['id'], $seleted_cast_id ?? []) ?  "checked" : "";
                                    echo '<li class="nav-item">
                            <input type="checkbox" name="cast[]" value="' . $row['id'] . '" ' . $is_checked . '>
                            <label for="' . $row['name'] . '">' . $row['name'] . '</label>
                            </li>';
                                }
                                ?>
                            </ul>

                        </div>
                        <!-- category -->
                        <div class="categories-filter ">
                            <h5>Categories</h5>
                            <ul class="nav flex-column">
                                <?php
                                while ($row = mysqli_fetch_assoc($categories_res)) {
                                    $is_checked = in_array($row['id'], $seleted_category_id ?? []) ?  "checked" : "";
                                    echo '<li class="nav-item">
                            <input type="checkbox" name="category[]" value="' . $row['id'] . '"  ' . $is_checked . '>
                            <label for="' . $row['name'] . '">' . $row['name'] . '</label>
                            </li>';
                                }
                                ?>
                            </ul>

                        </div>
                        <!-- directors -->
                        <div class="directors-filter ">
                            <h5>Director</h5>
                            <ul class="nav flex-column">
                                <?php
                                while ($row = mysqli_fetch_assoc($directors_res)) {
                                    $is_checked = in_array($row['id'], $seleted_director_id ?? []) ?  "checked" : "";
                                    echo '<li class="nav-item">
                            <input type="checkbox" name="directors[]" value="' . $row['id'] . '" ' . $is_checked . '>
                            <label for="' . $row['name'] . '">' . $row['name'] . '</label>
                            </li>';
                                }
                                ?>
                            </ul>

                        </div>

                        <!-- languages -->
                        <div class="languages-filter ">
                            <h5>Languages</h5>
                            <ul class="nav flex-column">
                                <?php
                                while ($row = mysqli_fetch_assoc($languages_res)) {

                                    $is_checked = in_array($row['id'], $seleted_language_id ?? []) ?  "checked" : "";
                                    echo '<li class="nav-item">
                                <input type="checkbox" name="languages[]" value="' . $row['id'] . '" ' . $is_checked . '>
                                <label for="' . $row['name'] . '">' . $row['name'] . '</label>
                                </li>';
                                }
                                ?>
                            </ul>
                        </div>
                        <!-- writers -->
                        <div class="writers-filter ">
                            <h5>Writer</h5>
                            <ul class="nav flex-column">
                                <?php
                                while ($row = mysqli_fetch_assoc($writers_res)) {
                                    $is_checked = in_array($row['id'], $seleted_writer_id ?? []) ?  "checked" : "";
                                    echo '<li class="nav-item">
                                <input type="checkbox" name="writers[]" value="' . $row['id'] . '" ' . $is_checked . '>
                                <label for="' . $row['name'] . '">' . $row['name'] . '</label>
                                </li>';
                                }
                                ?>
                            </ul>
                        </div>
                        <!-- genres -->
                        <div class="genres-filter ">
                            <h5>Genres</h5>
                            <ul class="nav flex-column">
                                <?php
                                while ($row = mysqli_fetch_assoc($genres_res)) {
                                    $is_checked = in_array($row['id'], $seleted_genre_id ?? []) ?  "checked" : "";
                                    echo '<li class="nav-item">
                            <input type="checkbox" name="genres[]" value="' . $row['id'] . '" ' . $is_checked . '>
                            <label for="' . $row['name'] . '">' . $row['name'] . '</label>
                            </li>';
                                }
                                ?>
                            </ul>
                        </div>

                    </sidebar>
                    <div class="mt-2">
                        <button type="button" class="btn btn-primary" id="filter">Filter</button>
                    </div>
                </div>
                <div class="col-10">
                    <div class="container">
                        <div class="row " id="movieDetails">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
<script>
    $.ajax({
        method: "GET",
        url: "./server/recommandedMovies.php",
        dataType: "json",
        success: function(response) {
            $('#movieDetails').empty();
            response.forEach(function(movieDetail) {
                $('#movieDetails').append(
                    ` <div class="col-md-3">
                    <div class="movie-card" data-toggle="modal" data-target="#movieModal${movieDetail.id}">
                        <img src="../adminSide/server/${movieDetail.image_url}" alt="Movie 1" class="img-fluid">
                        <hr/>
                        <h4>${movieDetail.title}</h4>
                        <p>${movieDetail.release_date}</p>
                        <p>${movieDetail.description}</p>
                    </div>
                  </div>

                  <div class="modal fade" id="movieModal${movieDetail.id}" tabindex="-1" role="dialog" aria-labelledby="movieModal1Label" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="movieModal1Label">${movieDetail.title}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <img src="../adminSide/server/${movieDetail.image_url}" alt="Movie 1" class="img-fluid mb-3" />
                        <b><p>Release Date: ${movieDetail.release_date}</p>
                        <p>${movieDetail.description}</p></b>
                      </div>
                    </div>
                  </div>
                </div>
                  
                  `);
            });
        }
    });
</script>
<?php include("footer.php") ?>
<script>
    $(document).ready(function() {
        $('#filter').click(function() {
            var cast = [];
            var category = [];
            var director = [];
            var genres = [];
            var languages = [];
            var tags = [];
            var writers = [];

            $('input[name="cast[]"]:checked').each(function() {
                cast.push(this.value);
            });
            $('input[name="category[]"]:checked').each(function() {
                category.push(this.value);
            });
            $('input[name="directors[]"]:checked').each(function() {
                director.push(this.value);
            });
            $('input[name="genres[]"]:checked').each(function() {
                genres.push(this.value);
            });
            $('input[name="languages[]"]:checked').each(function() {
                languages.push(this.value);
            });
            $('input[name="tags[]"]:checked').each(function() {
                tags.push(this.value);
            });
            $('input[name="writers[]"]:checked').each(function() {
                writers.push(this.value);
            });
            console.log("cast : ", cast);
            console.log("category : ", category);
            console.log("director : ", director);
            console.log("genres : ", genres);
            console.log("languages : ", languages);
            console.log("tags : ", tags);
            console.log("writers : ", writers);

            $.ajax({
                method: "POST",
                url: "./server/filterMovies.php",
                data: {
                    cast: cast,
                    category: category,
                    director: director,
                    genres: genres,
                    languages: languages,
                    tags: tags,
                    writers: writers
                },
                dataType: "json",
                success: function(response) {
                    console.log(response);

                }
            });
            location.reload();
        });
    });
</script>

</html>