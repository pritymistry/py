<link rel="stylesheet" href="./assets/bootstrap/css/style.css" />
<script src="./assets/js/code.jquery.com_jquery-3.7.1.min.js"></script>
<style>
    /* Add custom styles here */
    body {
        padding-top: 60px;
    }

    .jumbotron {
        background-color: #f8f9fa;
    }

    .movie-card {
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 10px;
        margin-bottom: 20px;
        cursor: pointer;
    }

    .movie-card h4 {
        margin-top: 0;
    }

    footer {
        background-color: #f8f9fa;
        padding: 10px 0;
    }

    .login-registration-container {
        max-width: 400px;
        margin: 0 auto;
        margin-top: 50px;
    }
</style>