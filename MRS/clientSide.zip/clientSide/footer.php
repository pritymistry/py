<footer class="fixed-bottom">
    <div class="container text-center">
        <span>&copy; 2023 Movie Recommendation System. All rights reserved.</span>
    </div>
</footer>
<script src="./assets/bootstrap/js/bootstrap.min.js"></script>
<script src="./assets/bootstrap/js/script.js"></script>
<script src="./assets/bootstrap/js/bootstar.min.js"></script>