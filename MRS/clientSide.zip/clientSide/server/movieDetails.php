<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);

$sql = "select * from movies";
$result = mysqli_query($connection, $sql);
$movieDetails = [];
foreach ($result as $r) {
    $movieDetails[] = $r;
}
header("Content-Type: application/json");
$response = $movieDetails;
echo json_encode($response);
exit();
