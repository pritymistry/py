<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);
//cheak all user_has_cast_preference table,user_has_category_preference table,user_has_directors_preference table,user_has_directors_preference table,user_has_language_preference table,user_has_tags_preference table,user_has_writers_preference table
if (isset($_SESSION['user_id'])) {

    //user_has_cast_preference table    
    $sql = "SELECT * FROM user_has_cast_preference WHERE user_id = '" . $_SESSION['user_id'] . "'";
    $result = $connection->query($sql);
    $cast = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cast[] = $row['cast_id'];
        }
    }
    //user_has_category_preference table
    $sql = "SELECT * FROM user_has_category_preference WHERE user_id = '" . $_SESSION['user_id'] . "'";
    $result = $connection->query($sql);
    $category = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $category[] = $row['category_id'];
        }
    }
    //user_has_directors_preference table
    $sql = "SELECT * FROM user_has_directors_preference WHERE user_id = '" . $_SESSION['user_id'] . "'";
    $result = $connection->query($sql);
    $directors = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $directors[] = $row['director_id'];
        }
    }
    //user_has_genre_preference table    
    $sql = "SELECT * FROM user_has_genre_preference WHERE user_id = '" . $_SESSION['user_id'] . "'";
    $result = $connection->query($sql);
    $genre = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $genre[] = $row['genre_id'];
        }
    }

    //user_has_language_preference table
    $sql = "SELECT * FROM user_has_language_preference WHERE user_id = '" . $_SESSION['user_id'] . "'";
    $result = $connection->query($sql);
    $language = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $language[] = $row['language_id'];
        }
    }
    //user_has_tags_preference table
    $sql = "SELECT * FROM user_has_tags_preference WHERE user_id = '" . $_SESSION['user_id'] . "'";
    $result = $connection->query($sql);
    $tags = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tags[] = $row['tag_id'];
        }
    }
    //user_has_writers_preference table
    $sql = "SELECT * FROM user_has_writers_preference WHERE user_id = '" . $_SESSION['user_id'] . "'";
    $result = $connection->query($sql);
    $writers = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $writers[] = $row['writer_id'];
        }
    }
    //cheak user preference data with movie_has_casts,movie_has_categories,movie_has_director,movie_has_genres,movie_has_languages,movie_has_tags,movie_has_writers and make a array of movie_id
    $movie_id = array();
    foreach ($cast as $cast_id) {
        $sql = "SELECT * FROM movie_has_casts WHERE cast_id = '" . $cast_id . "'";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $movie_id[] = $row['movie_id'];
            }
        }
    }
    foreach ($category as $category_id) {
        $sql = "SELECT * FROM movie_has_categories WHERE category_id = '" . $category_id . "'";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $movie_id[] = $row['movie_id'];
            }
        }
    }
    foreach ($directors as $directors_id) {
        $sql = "SELECT * FROM movie_has_director WHERE director_id = '" . $directors_id . "'";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $movie_id[] = $row['movie_id'];
            }
        }
    }
    foreach ($language as $language_id) {
        $sql = "SELECT * FROM movie_has_languages WHERE language_id = '" . $language_id . "'";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $movie_id[] = $row['movie_id'];
            }
        }
    }
    foreach ($tags as $tags_id) {
        $sql = "SELECT * FROM movie_has_tags WHERE tag_id = '" . $tags_id . "'";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $movie_id[] = $row['movie_id'];
            }
        }
    }
    foreach ($writers as $writers_id) {
        $sql = "SELECT * FROM movie_has_writers WHERE writer_id = '" . $writers_id . "'";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $movie_id[] = $row['movie_id'];
            }
        }
    }
    //remove duplicate movie_id
    $movie_id = array_unique($movie_id);
    //fetch all movies with $movie_id array
    $movie = array();
    foreach ($movie_id as $id) {
        $sql = "SELECT * FROM movies WHERE id = '" . $id . "'";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $movie[] = $row;
            }
        }
    }
    //remove duplicate movie
    $movie = array_unique($movie, SORT_REGULAR);
    header("Content-Type: application/json");
    echo json_encode($movie);
    exit();
    // echo "<pre>";
    // print_r($movie);
    // // echo json_encode($movie);
    // echo "</pre>";
} else {
    echo "Please login first";
}
