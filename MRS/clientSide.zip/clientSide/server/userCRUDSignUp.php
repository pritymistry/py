<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = mysqli_real_escape_string($connection, $_POST["username"]);
    $email = mysqli_real_escape_string($connection, $_POST["email"]);
    $password = mysqli_real_escape_string($connection, $_POST["password"]);
    $password = md5($password);

    //check email exist or not
    $email_check = "SELECT * FROM users WHERE email = '$email'";
    $res = mysqli_query($connection, $email_check);
    if (mysqli_num_rows($res) > 0) {
        $response = ["success" => false, "message" => "Email already exist"];
        header("Content-Type: application/json");
        echo json_encode($response);
        exit();
    }

    //write sql query for insert data in database table user(id,username,email,password)
    $sql = "INSERT INTO users(username,email, password) VALUES ('$username','$email','$password')";
    // Execute the query
    $result = mysqli_query($connection, $sql);
    // Check if the query was successful and return a response
    if ($result) {
        // Registration successful
        $response = ["success" => true, "message" => "User registered successfully"];
    } else {
        // Registration failed
        $response = ["success" => false, "message" => "Failed to add user"];
    }
    // Return the response as JSON
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
