<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
//session start
session_start();

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = mysqli_real_escape_string($connection, $_POST["email"]);
    $password = mysqli_real_escape_string($connection, $_POST["password"]);

    //craete login functionalty
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($connection, $sql);

    if ($result) {


        $row = mysqli_fetch_assoc($result);


        if (strcmp(md5($password), $row["password"]) == 0) {
            //set user in session
            $_SESSION["user_id"] = $row["id"];
            $_SESSION["username"] = $row["username"];
            $_SESSION["email"] = $row["email"];

            $response = ["success" => true, "message" => "Login successful"];
        } else {
            $response = ["success" => false, "message" => "Password incorrect"];
        }
    } else {
        $response = ["success" => false, "message" => "Email not found"];
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
