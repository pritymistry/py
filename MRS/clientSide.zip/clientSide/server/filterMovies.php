<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);
echo "<pre>";
print_r($_POST);
echo "</pre>";
//check that user_id session is set or not
if (isset($_SESSION["user_id"])) {
    $user_id = $_SESSION["user_id"];

    //check if user_id is present in users table or not
    $sql = "SELECT * FROM users WHERE id=$user_id";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        //echo "user_id is present in users table";
        //check if any data in user_has_cast_preference, user_has_category_preference, user_has_directors_preference, user_has_genre_preference, user_has_language_preference, user_has_tags_preference, user_has_writers_preference table is present or not for that user id if present then delete that data from that table for that user id and then insert new data
        $sql = "SELECT * FROM user_has_cast_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            echo "user id is present in user_has_cast_preference table";
            $sql = "DELETE FROM user_has_cast_preference WHERE user_id=$user_id";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "record deleted successfully";
            } else {
                echo "Error deleting record: " . $connection->error;
            }
        } else {
            echo "user id is not present in user_has_cast_preference table";
        }
        $sql = "SELECT * FROM user_has_category_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            echo "user id is present in user_has_category_preference table";
            $sql = "DELETE FROM user_has_category_preference WHERE user_id=$user_id";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "record deleted successfully";
            } else {
                echo "Error deleting record: " . $connection->error;
            }
        } else {
            echo "user id is not present in user_has_category_preference table";
        }
        $sql = "SELECT * FROM user_has_directors_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            echo "user id is present in user_has_directors_preference table";
            $sql = "DELETE FROM user_has_directors_preference WHERE user_id=$user_id";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "record deleted successfully";
            } else {
                echo "Error deleting record: " . $connection->error;
            }
        } else {
            echo "user id is not present in user_has_directors_preference table";
        }
        $sql = "SELECT * FROM user_has_genre_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            echo "user id is present in user_has_genre_preference table";
            $sql = "DELETE FROM user_has_genre_preference WHERE user_id=$user_id";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "record deleted successfully";
            } else {
                echo "Error deleting record: " . $connection->error;
            }
        } else {
            echo "user id is not present in user_has_genre_preference table";
        }
        $sql = "SELECT * FROM user_has_language_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            echo "user id is present in user_has_language_preference table";
            $sql = "DELETE FROM user_has_language_preference WHERE user_id=$user_id";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "record deleted successfully";
            } else {
                echo "Error deleting record: " . $connection->error;
            }
        } else {
            echo "user id is not present in user_has_language_preference table";
        }
        $sql = "SELECT * FROM user_has_tags_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            echo "user id is present in user_has_tags_preference table";
            $sql = "DELETE FROM user_has_tags_preference WHERE user_id=$user_id";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "record deleted successfully";
            } else {
                echo "Error deleting record: " . $connection->error;
            }
        } else {
            echo "user id is not present in user_has_tags_preference table";
        }
        $sql = "SELECT * FROM user_has_writers_preference WHERE user_id=$user_id";
        $result = $connection->query($sql);
        if ($result->num_rows > 0) {
            echo "user id is present in user_has_writers_preference table";
            $sql = "DELETE FROM user_has_writers_preference WHERE user_id=$user_id";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "record deleted successfully";
            } else {
                echo "Error deleting record: " . $connection->error;
            }
        } else {
            echo "user id is not present in user_has_writers_preference table";
        }
        //insert new data in user_has_cast_preference, user_has_category_preference, user_has_directors_preference, user_has_genre_preference, user_has_language_preference, user_has_tags_preference, user_has_writers_preference table for that user id
        $cast = $_POST["cast"];
        $category = $_POST["category"];
        $director = $_POST["director"];
        $genres = $_POST["genres"];
        $languages = $_POST["languages"];
        $tags = $_POST["tags"];
        $writers = $_POST["writers"];
        foreach ($cast as $cast_id) {
            $sql = "INSERT INTO user_has_cast_preference (user_id, cast_id) VALUES ($user_id, $cast_id)";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
        foreach ($category as $category_id) {
            $sql = "INSERT INTO user_has_category_preference (user_id, category_id) VALUES ($user_id, $category_id)";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
        foreach ($director as $director_id) {
            $sql = "INSERT INTO user_has_directors_preference (user_id, director_id) VALUES ($user_id, $director_id)";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
        foreach ($genres as $genre_id) {
            $sql = "INSERT INTO user_has_genre_preference (user_id, genre_id) VALUES ($user_id, $genre_id)";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
        foreach ($languages as $language_id) {
            $sql = "INSERT INTO user_has_language_preference (user_id, language_id) VALUES ($user_id, $language_id)";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
        foreach ($tags as $tag_id) {
            $sql = "INSERT INTO user_has_tags_preference (user_id, tag_id) VALUES ($user_id, $tag_id)";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
        foreach ($writers as $writer_id) {
            $sql = "INSERT INTO user_has_writers_preference (user_id, writer_id) VALUES ($user_id, $writer_id)";
            $result = $connection->query($sql);
            if ($result === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
        return $response = ["message : " + "data inserted successfully"];
        exit();
    } else {
        echo "user_id is not present in users table";
        exit();
    }



    echo $user_id;
} else {
    echo "user_id session is not set";
    exit();
}
