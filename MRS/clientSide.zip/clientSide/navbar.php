<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);
$sql = "select * from categories";
$res = mysqli_query($connection, $sql);
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <a class="navbar-brand" href="index.php">Movie Recommendation System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#movieDetails">Movies</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Categories
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <?php
          foreach ($res as $r) {
            echo "<a class=dropdown-item href=categories.php?category_id=" . $r['id'] . ">" . $r['name'] . "</a>";
          }
          ?>
        </div>
      </li>
      <?php
      if (isset($_SESSION['user_id'])) {
        echo ' <li class="nav-item">
          <a class="nav-link" href="recommendation.php">Recommendations</a>
          </li>';
      }
      ?>
      <?php
      if (!isset($_SESSION["user_id"])) {

        echo  '<li class="nav-item">
    <a class="nav-link" href="#" data-toggle="modal" data-target="#loginModal">Sign In</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#" data-toggle="modal" data-target="#registrationModal">Sign Up</a>
  </li>';
      } else if (isset($_SESSION["user_id"])) {
        echo '  <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Welcome, ' . $_SESSION["username"] . ' 
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class=dropdown-item href=./signout.php>SignOut</a>
            </div>
            </li>';
      }
      ?>
    </ul>
  </div>
</nav>

<!-- login Model -->
<?php include("./Models/loginModel.php"); ?>

<!-- login model end -->

<!-- Registration Model -->
<?php include("./Models/RegistrationModel.php"); ?>

<!-- Registration  end -->

<!-- //   echo  '<li class="nav-item">'.$_SESSION["username"] .'
        //   <a class="nav-link" href="./signout.php" >Sign Out</a>
        // </li>
        // '; -->