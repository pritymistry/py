<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mrc";
$connection = new mysqli($servername, $username, $password, $dbname);

//get category_id from _GET url
$category_id = $_GET['category_id'];

//check if category_id is set or not
if (!isset($category_id)) {
    header("Location: index.php");
}

//check if category_id is valid or not
$sql = "SELECT * FROM categories WHERE id = '" . $category_id . "'";
$result = $connection->query($sql);
if ($result->num_rows == 0) {
    header("Location: index.php");
}

//collect all movies from category_id from movie_has_categories table
$sql = "SELECT * FROM movie_has_categories WHERE category_id = '" . $category_id . "'";
$result = $connection->query($sql);
$movies_ids = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $movies_ids[] = $row['movie_id'];
    }
}

//collect all movies from movies table
$movies = array();
foreach ($movies_ids as $movie_id) {
    $sql = "SELECT * FROM movies WHERE id = '" . $movie_id . "'";
    $result = $connection->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $movies[] = $row;
        }
    }
}

// echo "<pre>";
// print_r($movies);
// echo "</pre>";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("header.php");
    session_start();
    ?>
</head>


<body>
    <!-- nav -->
    <?php include("navbar.php"); ?>
    <!-- nav end -->
    <div class="row m-5" id="movieDetails">
        <?php
        foreach ($movies as $movieDetail) {
            echo '<div class="col-md-3">
            <div class="movie-card" data-toggle="modal" data-target="#movieModal' . $movieDetail['id'] . '">
                <img src="../adminSide/server/' . $movieDetail['image_url'] . '" alt="Movie 1" class="img-fluid">
                <hr/>
                <h4>' . $movieDetail['title'] . '</h4>
                <p>' . $movieDetail['release_date'] . '</p>
                <p>' . $movieDetail['description'] . '</p>
            </div>
          </div>
          

          <div class="modal fade" id="movieModal' . $movieDetail['id'] . '" tabindex="-1" role="dialog" aria-labelledby="movieModal1Label" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="movieModal1Label">' . $movieDetail['title'] . '</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <img src="../adminSide/server/' . $movieDetail['image_url'] . '" alt="Movie 1" class="img-fluid mb-3" />
                <b><p>Release Date: ' . $movieDetail['release_date'] . '</p>
                <p>' . $movieDetail['description'] . '</p></b>
              </div>
            </div>
          </div>
        </div>
          
          ';
        }
        ?>
    </div>
    <?php include("footer.php") ?>
</body>


</html>